package rest.controller;

import java.io.InputStream;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import com.sun.jersey.core.header.FormDataContentDisposition;
import com.sun.jersey.multipart.FormDataParam;

import rest.dao.CarroDAO;
import rest.model.Carro;

@Path("/carros")
public class CarroService {

	@GET
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	public List<Carro> getCarros() {
		return CarroDAO.getAllCarros();
	}

	// Controle da resposta (status code, mensagem)
	@GET
	@Path("/{id}")
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	public Response getCarro(@PathParam("id") int id) {
		return Response.status(Status.OK).entity(CarroDAO.getCarro(id)).build();
	}

	@GET
	@Path("/search")
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	public Carro getCarroByNome(@QueryParam("nome") String nome) {
		return CarroDAO.getCarroByNome(nome);
	}

	@POST
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Consumes(MediaType.MULTIPART_FORM_DATA)
	public Carro addCarro(@FormDataParam("image") InputStream uploadedInputStream,
		@FormDataParam("nome") String nome, @FormDataParam("marca") String marca,@FormDataParam("AnoDefabricacao") int AnoDefabricacao, @FormDataParam("AnoDeModelo") int AnoDeModelo, @FormDataParam("dataDeVenda") String dataDeVenda) {

		return CarroDAO.addCarro(nome,marca,AnoDefabricacao, AnoDeModelo, dataDeVenda, uploadedInputStream);
	}

	@PUT
	@Path("/{id}")
	@Consumes(MediaType.MULTIPART_FORM_DATA)
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	public Carro updateCarro(@PathParam("id") int id, @FormDataParam("image") InputStream uploadedInputStream,
			@FormDataParam("image") FormDataContentDisposition contentDispositionHeader,
			@FormDataParam("nome") String nome, @FormDataParam("marca") String marca,@FormDataParam("AnoDefabricacao") int AnoDefabricacao, @FormDataParam("AnoDeModelo") int AnoDeModelo, @FormDataParam("dataDeVenda") String dataDeVenda) {
		
		if(contentDispositionHeader.getFileName() == null) {
			return CarroDAO.updateCarro(id, nome, marca, AnoDefabricacao, AnoDeModelo, dataDeVenda, null);	
		} else {
			return CarroDAO.updateCarro(id, nome, marca, AnoDefabricacao, AnoDeModelo, dataDeVenda, uploadedInputStream);
		}
	}

	@DELETE
	@Path("/{id}")
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	public void deleteCarro(@PathParam("id") int id) {
		CarroDAO.deleteCarro(id);
	}
	
	//Session
	@POST
	@Path("/oi")
	@Consumes(MediaType.MULTIPART_FORM_DATA)
    @Produces("application/json")
    public Response hello(@Context HttpServletRequest req, @FormDataParam("nome") String nome) {
        HttpSession session = req.getSession(true);
        Object foo = session.getAttribute("foo");
        System.out.println(session.getId());
        
        if (foo != null) {
            System.out.println(foo.toString());
        } else {
            foo = "bar";
            session.setAttribute("foo", foo);
            System.out.println("first");
        }
        
        return Response.status(Status.OK).entity(foo.toString()).build();
    }
}