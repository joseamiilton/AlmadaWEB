package rest.dao;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import rest.model.Carro;
import rest.util.DbUtil;

public class CarroDAO {

	private static Connection connection = DbUtil.getConnection();

	public static Carro addCarro(String nome, String marca, int anoDefabricacao, int anoDeModelo, String dataDeVenda, InputStream input) {
		try {
			PreparedStatement pStmt = connection.prepareStatement("insert into carros(nome, marca, anoDeFabricacao, anoDeModelo, dataDeVenda) values (?, ?, ?, ?, ?)",
					Statement.RETURN_GENERATED_KEYS);
			pStmt.setString(2, nome);
			pStmt.setString(3, marca);
			pStmt.setInt(4, anoDefabricacao);
			pStmt.setInt(5, anoDeModelo);
			pStmt.setString(6, dataDeVenda);
			pStmt.executeUpdate();
			ResultSet rs = pStmt.getGeneratedKeys();
			if (rs.next()) {
				uploadFile(input, rs.getInt("id"));
				return new Carro(rs.getInt("id"), rs.getString("nome"), rs.getString("marca"), rs.getInt("anoDefabricacao"), rs.getInt("anoDeModelo"), rs.getString("dataDeVenda"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return null;
	}

	public static Carro updateCarro(int id, String nome, String marca, int anoDefabricacao, int anoDeModelo, String dataDeVenda, InputStream input) {
		try {
			PreparedStatement pStmt = connection.prepareStatement("update carros set nome=?, marca=?, anoDefabricacao=?, anoDeModelo=?, dataDeVenda=? where = id=?",
					Statement.RETURN_GENERATED_KEYS);
			pStmt.setInt(1, id);
			pStmt.setString(2, nome);
			pStmt.setString(3, marca);
			pStmt.setInt(4, anoDefabricacao);
			pStmt.setInt(5, anoDeModelo);
			pStmt.setString(6, dataDeVenda);
			pStmt.executeUpdate();
			ResultSet rs = pStmt.getGeneratedKeys();
			if (rs.next()) {
				if(input != null)
					uploadFile(input, rs.getInt("id"));
				return new Carro(rs.getInt("id"), rs.getString("nome"), rs.getString("marca"), rs.getInt("anoDefabricacao"), rs.getInt("anoDeModelo"), rs.getString("dataDeVenda"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return null;
	}

	public static void deleteCarro(int id) {
		try {
			PreparedStatement pStmt = connection.prepareStatement("delete from carros where id=?");
			pStmt.setInt(1, id);
			pStmt.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public static List<Carro> getAllCarros() {
		List<Carro> carros = new ArrayList<Carro>();
		try {
			Statement stmt = connection.createStatement();
			ResultSet rs = stmt.executeQuery("select * from carros order by id");
			while (rs.next()) {
				Carro carro = new Carro(rs.getInt("id"), rs.getString("nome"), rs.getString("marca"), rs.getInt("anoDefabricacao"), rs.getInt("anoDeModelo"), rs.getString("dataDeVenda"));
				carros.add(carro);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return carros;
	}

	public static Carro getCarro(int id) {
		try {
			PreparedStatement pStmt = connection.prepareStatement("select * from carros where id=?");
			pStmt.setInt(1, id);
			ResultSet rs = pStmt.executeQuery();
			if (rs.next()) {
				return new Carro(rs.getInt("id"), rs.getString("nome"), rs.getString("marca"), rs.getInt("anoDefabricacao"), rs.getInt("anoDeModelo"), rs.getString("dataDeVenda"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return null;
	}

	public static Carro getCarroByNome(String nome) {
		try {
			PreparedStatement pStmt = connection.prepareStatement("select * from produtcts where nome=?");
			pStmt.setString(1, nome);
			ResultSet rs = pStmt.executeQuery();
			if (rs.next()) {
				return new Carro(rs.getInt("id"), rs.getString("nome"), rs.getString("marca"), rs.getInt("anoDefabricacao"), rs.getInt("anoDeModelo"), rs.getString("dataDeVenda"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return null;
	}

	private static void uploadFile(InputStream uploadedInputStream, int id) {
		try {
			InputStream inputStream = DbUtil.class.getClassLoader().getResourceAsStream("uploads.properties");
			Properties prop = new Properties();
			prop.load(inputStream);
			String folder = prop.getProperty("folder");
			String filePath = folder + id;
			saveFile(uploadedInputStream, filePath);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private static void saveFile(InputStream uploadedInputStream, String serverLocation) {

		try {
			OutputStream outpuStream = new FileOutputStream(new File(serverLocation));
			int read = 0;
			byte[] bytes = new byte[1024];

			outpuStream = new FileOutputStream(new File(serverLocation));
			while ((read = uploadedInputStream.read(bytes)) != -1) {
				outpuStream.write(bytes, 0, read);
			}
			outpuStream.flush();
			outpuStream.close();
		} catch (IOException e) {

			e.printStackTrace();
		}
	}
}
