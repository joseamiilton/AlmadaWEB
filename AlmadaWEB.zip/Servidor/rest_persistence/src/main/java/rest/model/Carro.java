package rest.model;

import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAccessType;

@XmlRootElement(name = "produto")
@XmlAccessorType(XmlAccessType.FIELD)
public class Carro {
	
	private int id;
	private String nome;
	private String marca;
	private int anoDefabricacao;
	private int anoDeModelo;
	private String dataDeVenda;
	
	public Carro(int id, String nome, String marca, int anoDefabricacao, int anoDeModelo, String dataDeVenda) {
		super();
		this.id = id;
		this.nome = nome;
		this.marca = marca;
		this.anoDefabricacao = anoDefabricacao;
		this.anoDeModelo = anoDeModelo;
		this.dataDeVenda = dataDeVenda;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getMarca() {
		return marca;
	}
	public void setMarca(String marca) {
		this.marca = marca;
	}
	public int getAnoDefabricacao() {
		return anoDefabricacao;
	}
	public void setAnoDefabricacao(int anoDefabricacao) {
		this.anoDefabricacao = anoDefabricacao;
	}
	public int getAnoDeModelo() {
		return anoDeModelo;
	}
	public void setAnoDeModelo(int anoDeModelo) {
		this.anoDeModelo = anoDeModelo;
	}
	public String getDataDeVenda() {
		return dataDeVenda;
	}
	public void setDataDeVenda(String dataDeVenda) {
		this.dataDeVenda = dataDeVenda;
	}

	@Override
	public String toString() {
		return "Produto [nome=" + nome + ", marca=" + marca + ", anoDefabricacao=" + anoDefabricacao + ", anoDeModelo="
				+ anoDeModelo + ", dataDeVenda=" + dataDeVenda + "]";
	}
	
}
